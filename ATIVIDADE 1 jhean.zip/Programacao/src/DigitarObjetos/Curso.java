package DigitarObjetos;

public class Curso {
	public String turno;
	public String nomeCurso;
	public int semestres;
	
	
	public String getTurno() {
		return turno;
	}
	public void setTurno(String turno) {
		this.turno = turno;
	}
	public String getNomeCurso() {
		return nomeCurso;
	}
	public void setNomeCurso(String nomeCurso) {
		this.nomeCurso = nomeCurso;
	}
	public int getSemestres() {
		return semestres;
	}
	public void setSemestres(int semestres) {
		this.semestres = semestres;
	}
	
	
}
