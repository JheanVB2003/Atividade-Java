package DigitarObjetos;
import java.util.Scanner;

public class Main {
	
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);	
		Curso curso = new Curso();
		Aluno aluno = new Aluno();
		Professor professor = new Professor();
		Disciplina disciplina = new Disciplina();
		String res;
		
		do {
			System.out.println("Você deseja realizar o cadastro de um aluno ou professor? ");
			res = scan.nextLine();
		
			if(res.equals("aluno") || res.equals("Aluno")) {
				System.out.println("--------------ÁREA DO ALUNO--------------");
				System.out.println("Digite seu nome: ");
				aluno.nomeAluno = scan.nextLine();
				System.out.println("Olá "+ aluno.nomeAluno +", qual é o seu curso: ");
				curso.nomeCurso = scan.nextLine();
				System.out.println("Qual é o seu turno: ");
				curso.turno = scan.nextLine();
				System.out.println("Digite seu gmail: ");
				aluno.emailAluno = scan.nextLine();
				System.out.println("Seu curso têm quantos semestres? ");
				curso.semestres = scan.nextInt();
				System.out.println("Qual é sua idade " +aluno.nomeAluno+ "? ");
				aluno.idade = scan.nextInt();
				System.out.println("Digite sua matrícula: ");
				aluno.matricula = scan.nextInt();
				System.out.println("Para finalizar digite seu CPF: (Dê um clique no espaço a cada ponto ou hífen)");
				System.out.println("EXEMPLO: 123 456 789 12");
				aluno.cpfAluno = scan.next();
				aluno.cpfAluno1 = scan.next();
				aluno.cpfAluno2 = scan.next();
				aluno.cpfAluno3 = scan.next();
				

				System.out.println("--------------INFORMAÇÕES DIGITADAS--------------");
				System.out.println("O nome do Aluno digitado foi: " +aluno.getNomeAluno());
				System.out.println("O curso digitado foi: " +curso.getNomeCurso());
				System.out.println("O turno digitado foi: " +curso.getTurno());
				System.out.println("O gmail digitado foi: " +aluno.getEmailAluno());
				System.out.println("A quantidade de Semestres digitada foi: " +curso.getSemestres());
				System.out.println("A idade digitada foi: " +aluno.getIdade());
				System.out.println("A matrícula digitada foi: " +aluno.getMatricula());
				System.out.println("CPF: " +aluno.cpfAluno+"." +aluno.cpfAluno1+"." +aluno.cpfAluno2+"-" +aluno.cpfAluno3);
			}
			else if(res.equals("Professor") || res.equals("professor"))
			{
				System.out.println("--------------ÁREA DO PROFESSOR--------------");
				System.out.println("Digite seu nome: ");
				professor.nomeProfessor = scan.nextLine();
				System.out.println("Olá "+ professor.nomeProfessor +", qual seus cursos? ");
				curso.nomeCurso = scan.nextLine();
				System.out.println("Qual sua carga horária? ");
				disciplina.cargaHoraria = scan.nextLine();
				System.out.println("Com qual linguagem o(a) Senhor(a) mais trabalha? ");
				disciplina.Linguagem = scan.nextLine();
				System.out.println("Digite seu email para contato: ");
				professor.emailProfessor = scan.nextLine();
				System.out.println("Para finalizar digite seu CPF: (Dê um clique no espaço a cada ponto ou hífen)");
				System.out.println("EXEMPLO: 123 456 789 12");
				professor.cpfProfessor = scan.next();
				professor.cpfProfessor1 = scan.next();
				professor.cpfProfessor2 = scan.next();
				professor.cpfProfessor3 = scan.next();
				System.out.println("Digite sua idade: ");
				professor.idade = scan.nextInt();


				System.out.println("--------------INFORMAÇÕES DIGITADAS--------------");
				System.out.println("O nome do Professor digitado foi: " +professor.getNomeProfessor());
				System.out.println("Os cursos digitados foram: " +curso.getNomeCurso());
				System.out.println("A carga horária digitada: " +disciplina.getCargaHoraria()+" horas");
				System.out.println("As linguagens que o(a) Senhor(a) mais trabalha: "+disciplina.getLinguagem());
				System.out.println("O e-mail para contato é: " +professor.getEmailProfessor());
				System.out.println("CPF: " +professor.cpfProfessor+"." +professor.cpfProfessor1+"." +professor.cpfProfessor2+"-" +professor.cpfProfessor3);
				System.out.println("A idade digitada foi: " +professor.getIdade());
				
			}

		}while(res == "aluno" && res == "Aluno" && res == "professor" && res == "Professor");
	}
}
