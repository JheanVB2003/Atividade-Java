package DigitarObjetos;

public class Professor {
	public int idade;
	public String nomeProfessor;
	public String cpfProfessor;
	public String cpfProfessor1;
	public String cpfProfessor2;
	public String cpfProfessor3;
	public String emailProfessor;
	
	
	
	public int getIdade() {
		return idade;
	}
	public void setIdade(int idade) {
		this.idade = idade;
	}
	public String getNomeProfessor() {
		return nomeProfessor;
	}
	public void setNomeProfessor(String nomeProfessor) {
		this.nomeProfessor = nomeProfessor;
	}
	public String getCpfProfessor() {
		return cpfProfessor;
	}
	public void setCpfProfessor(String cpfProfessor) {
		this.cpfProfessor = cpfProfessor;
	}
	public String getEmailProfessor() {
		return emailProfessor;
	}
	public void setEmailProfessor(String emailProfessor) {
		this.emailProfessor = emailProfessor;
	}
	public String getCpfProfessor1() {
		return cpfProfessor1;
	}
	public void setCpfProfessor1(String cpfProfessor1) {
		this.cpfProfessor1 = cpfProfessor1;
	}
	public String getCpfProfessor2() {
		return cpfProfessor2;
	}
	public void setCpfProfessor2(String cpfProfessor2) {
		this.cpfProfessor2 = cpfProfessor2;
	}
	public String getCpfProfessor3() {
		return cpfProfessor3;
	}
	public void setCpfProfessor3(String cpfProfessor3) {
		this.cpfProfessor3 = cpfProfessor3;
	}
	
	
}
