package DigitarObjetos;

public class Disciplina {
	public String Linguagem;
	public String cargaHoraria;
	
	
	public String getLinguagem() {
		return Linguagem;
	}
	public void setLinguagem(String linguagem) {
		Linguagem = linguagem;
	}
	public String getCargaHoraria() {
		return cargaHoraria;
	}
	public void setCargaHoraria(String cargaHoraria) {
		this.cargaHoraria = cargaHoraria;
	}
	
	
}
