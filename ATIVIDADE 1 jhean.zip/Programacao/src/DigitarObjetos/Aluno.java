package DigitarObjetos;

public class Aluno {
	public int idade;
	public int matricula;
	public String nomeAluno;
	public String cpfAluno;
	public String cpfAluno1;
	public String cpfAluno2;
	public String cpfAluno3;
	public String emailAluno;
	
	
	public String getCpfAluno1() {
		return cpfAluno1;
	}
	public void setCpfAluno1(String cpfAluno1) {
		this.cpfAluno1 = cpfAluno1;
	}
	public String getCpfAluno2() {
		return cpfAluno2;
	}
	public void setCpfAluno2(String cpfAluno2) {
		this.cpfAluno2 = cpfAluno2;
	}
	public String getCpfAluno3() {
		return cpfAluno3;
	}
	public void setCpfAluno3(String cpfAluno3) {
		this.cpfAluno3 = cpfAluno3;
	}
	public int getIdade() {
		return idade;
	}
	public void setIdade(int idade) {
		this.idade = idade;
	}
	public int getMatricula() {
		return matricula;
	}
	public void setMatricula(int matricula) {
		this.matricula = matricula;
	}
	public String getNomeAluno() {
		return nomeAluno;
	}
	public void setNomeAluno(String nomeAluno) {
		this.nomeAluno = nomeAluno;
	}
	public String getCpfAluno() {
		return cpfAluno;
	}
	public void setCpfAluno(String cpfAluno) {
		this.cpfAluno = cpfAluno;
	}
	public String getEmailAluno() {
		return emailAluno;
	}
	public void setEmailAluno(String emailAluno) {
		this.emailAluno = emailAluno;
	}
	
	
}
