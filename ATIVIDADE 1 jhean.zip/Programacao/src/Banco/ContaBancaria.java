package Banco;

public class ContaBancaria {

	public String agencia;
	public String conta;
	protected double saldo; //só acessado por uma senha
	private int numeroCartao; //só é acessado por pessoas específicas
	public String validade;
	private int codseguranca;
	
	
	public String getAgencia() {
		return agencia;
	}
	public void setAgencia(String agencia) {
		this.agencia = agencia;
	}
	public String getConta() {
		return conta;
	}
	public void setConta(String conta) {
		this.conta = conta;
	}
	public double getSaldo() {
		return saldo;
	}
	public void setSaldo(double saldo) {
		this.saldo = saldo;
	}
	public int getNumeroCartao() {
		return numeroCartao;
	}
	public void setNumeroCartao(int numeroCartao) {
		this.numeroCartao = numeroCartao;
	}
	public String getValidade() {
		return validade;
	}
	public void setValidade(String validade) {
		this.validade = validade;
	}
	public int getCodseguranca() {
		return codseguranca;
	}
	public void setCodseguranca(int codseguranca) {
		this.codseguranca = codseguranca;
	}
	
	
}