package Banco;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
	Scanner scan = new Scanner(System.in);
	
		ContaBancaria conta01 = new ContaBancaria(); //Criação de objeto
		conta01.setAgencia("12094-4");
		conta01.setConta("2727-8");
		conta01.setSaldo(00);
		
		ContaBancaria conta02 = new ContaBancaria();
		
		System.out.println("Sua agência:"+ conta01.getAgencia()+" Sua conta:"+conta01.getConta()+" Seu saldo:"+conta01.getSaldo());


	}

}
